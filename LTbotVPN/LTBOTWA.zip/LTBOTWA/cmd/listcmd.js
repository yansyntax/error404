const fs = require('fs');
module.exports = async ({ lunaticreply }) => {
try {
const files = fs.readdirSync('./cmd').filter(file => file.endsWith('.js'));
if (!files.length) return lunaticreply('⚠️ Tidak ada file di folder cmd/');
const list = files.map((f, i) => `├─ ${f}`).join('\n');
lunaticreply(`📁 *Daftar CMD di Bot:*\n${list}\n\n📌 Total: ${files.length} file`);
} catch (e) {
lunaticreply(`❌ Gagal membaca folder cmd:\n${e.message}`);
}
};