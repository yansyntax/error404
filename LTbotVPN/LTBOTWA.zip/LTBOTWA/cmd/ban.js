const fs = require('fs')
const path = './avars/banned.json'

// Buat file jika belum ada
if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify([]))

module.exports = async ({ lunaticreply, q, isAdmin }) => {
    if (!isAdmin) return lunaticreply("❌ Kamu bukan admin bot!")

    if (!q) return lunaticreply("⚠️ Masukan Nomor yg mau di ban.\n\n Contoh: !ban 628xxx")

    const nomor = q.replace(/[^0-9]/g, '')

    if (nomor.length < 8) return lunaticreply("❌ Nomor tidak valid!")

    const banned = JSON.parse(fs.readFileSync(path))

    if (banned.includes(nomor)) return lunaticreply("⚠️ Nomor sudah diblokir sebelumnya.")

    banned.push(nomor)
    fs.writeFileSync(path, JSON.stringify(banned, null, 2))

    lunaticreply(`✅ Nomor ${nomor} telah diblokir dari menggunakan bot.`)
}
