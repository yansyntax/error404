const fs = require('fs');
const axios = require('axios');

module.exports = async ({ q, lunaticreply, isAdmin, isOwner }) => {
  // 🔒 Batasi akses hanya Admin & Owner
  if (!isAdmin && !isOwner) {
    return lunaticreply('❌ ```husus Admin atau Owner``` ');
  }

  // ✅ Validasi input
  if (!q) return lunaticreply(`❌ Format: \nregistip nama exp ipvps\n\nContoh:\nregistip lunatic 30 188.6.1`);

  const args = q.trim().split(/\s+/);
  if (args.length < 3) {
    return lunaticreply(`❌ Format: \nregistip nama exp ipvps\n\nContoh:\nregistip lunatic 30 188.166.246.1`);
  }

  const [nama, lamaStr, ipvps] = args;
  const lama = parseInt(lamaStr);
  if (isNaN(lama) || lama < 1) {
    return lunaticreply(`🟢 Masa aktif harus berupa angka (dalam hari)`);
  }

  // 📅 Hitung tanggal expired
  const now = new Date();
  now.setDate(now.getDate() + lama);
  const expiredDate = now.toISOString().split('T')[0]; // YYYY-MM-DD

  const barisBaru = `### ${nama} ${expiredDate} ${ipvps}`;

  // 🔐 Ambil token dari file
  let token;
  try {
    const tk = JSON.parse(fs.readFileSync('./avars/tokengh.json'));
    token = tk.token;
  } catch {
    return lunaticreply(`❌ Gagal membaca token GitHub di avars/tokengh.json`);
  }

  if (!token) {
    return lunaticreply(`❌ Token GitHub belum diset!`);
  }

  const owner = 'ianexec';
  const repo = 'permission';
  const path = 'regist';
  const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;

  try {
    // 📥 Ambil isi file `regist` dari GitHub
    const { data } = await axios.get(apiUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github.v3+json',
      },
    });

    const content = Buffer.from(data.content, 'base64').toString();
    const updatedContent = content.trim() + `\n${barisBaru}\n`;

    const newEncoded = Buffer.from(updatedContent, 'utf-8').toString('base64');

    // 📤 Kirim update ke GitHub
    await axios.put(apiUrl, {
      message: `registip: tambah ${nama}`,
      content: newEncoded,
      sha: data.sha,
    }, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github.v3+json',
      },
    });

    lunaticreply(`✅ IPvps berhasil diregistrasi!\n\n📌 ${barisBaru}`);
  } catch (err) {
    console.error('[REGISTIP ERROR]', err.response?.data || err.message);
    lunaticreply(`❌ Gagal push ke GitHub.\nPastikan token valid dan repo ada.`);
  }
};