const { exec } = require('child_process');
const fs = require('fs');

module.exports = async ({ isOwner, isAdmin, q, lunaticreply }) => {
    if (!isAdmin && !isOwner) return lunaticreply("❌ ```KHUSUS LUNATIC``` ");

  // Ambil prefix dari prefix.json
  let prefix = '!';
  try {
    const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
    prefix = pf.prefix || '!';
  } catch {}
  // BATAS AMBIL GLOBAL PREFIX 
  
  // 🔧 Validasi input
  if (!q) return lunaticreply("Contoh:\n${prefix}installsc <ip_vps> <password>");
  const args = q.trim().split(/\s+/);
  if (args.length !== 2) {
    return lunaticreply("Contoh:\n${prefix}installsc <ip_vps> <password>");
  }

  const [ip, pass] = args;
  const user = 'root';
  const port = 22;
  const scriptPath = '/root/LTBOTWA/shell_scripts/install_tunnel.sh';

  // 🕐 Kirim respon awal biar WA gak timeout
  await lunaticreply(`🛠️ Sedang menginstall script ke VPS *${ip}*...`);

  const cmd = `bash ${scriptPath} ${ip} ${user} '${pass}' ${port}`;
  exec(cmd, { maxBuffer: 1024 * 500 }, (err, stdout, stderr) => {
    const output = err
      ? `❌ Gagal install VPS *${ip}*:\n\n${stderr || stdout || err.message}`
      : `✅ *Install sukses VPS ${ip}:*\n\n${stdout.trim()}`;

    lunaticreply(output.slice(0, 4000)); // ⛔ WA limit 4096
  });
};