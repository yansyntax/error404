module.exports = async ({ isAdmin,  lunatix, msg, lunaticreply }) => {
  const caption = `
━━━━━━━━━━━━━━━━━  
*JOIN LUNATIC GROUP*
━━━━━━━━━━━━━━━━━
*Join Config Prem Murah:*
> *GRUP PRIVAT*
https://chat.whatsapp.com/Gg5eN9rnjFoK30Jk7COWM5
━━━━━━━━━━━━━━━━━
*Join Grup Berbagi config:*
> *GRUP PUBLIC*
https://chat.whatsapp.com/FR4xHcfW6IMB6aS0gSP7Gt
━━━━━━━━━━━━━━━━━
*Ssh Premium Free:*
https://whatsapp.com/channel/0029VbB0b0UCMY0FC3TX6Q2r
━━━━━━━━━━━━━━━━━
*Testimoni:*
https://whatsapp.com/channel/0029Vb5ZrXsBlHpWwWjw6v1i
━━━━━━━━━━━━━━━━━
  `.trim();

  await lunatix.sendMessage(msg.key.remoteJid, {
    text: caption,
  }, { quoted: msg });
};
